var ImageEditor = { margin: 50, instanceId: 0 };

ImageEditor.GetAspectRatioName = function (mustPortraitOrientationBeUsed) {
  return 'custom';
  //  return mustPortraitOrientationBeUsed ? 'portrait' : 'landscape';
}

ImageEditor.GetAspectRatio = function (mustPortraitOrientationBeUsed) {
  return mustPortraitOrientationBeUsed ? (2.0 / 3.0) : (3.0 / 2.0);
}

ImageEditor.ClearEditorContainer = function () {
  $("#editor_external_div" + this.instanceId).css("display", "none");
}

ImageEditor.CreateEditorContainer = function () {
  this.instanceId++;
  $("#lightboxes").append(this.GetContainerHTML());

  $("#editor_external_div" + this.instanceId).css("display", "");

  var body = (document.compatMode == 'CSS1Compat' && !window.opera) ? document.documentElement : document.body;
  var editorWidth = body.clientWidth - this.margin;
  var editorHeight = body.clientHeight - this.margin;

  var container = document.getElementById('editor' + this.instanceId);
  container.style.width = "" + editorWidth + "px";
  container.style.height = "" + editorHeight + "px";

  return container;
}

ImageEditor.GetContainerHTML = function () {
  var html = "<div class='lightbox' id='editor_external_div" + this.instanceId + "' style='display: none;'>";
  html += "<div class='lightbox-inner'>";
  html += "<div class='content' id='editor" + this.instanceId + "' style='width: 640px; height: 480px;'></div>";
  html += "</div>";
  html += "</div>";
  return html;
}

ImageEditor.GetEditorParams = function (img, mustPortraitOrientationBeUsed) {
    this.container = this.CreateEditorContainer();

  //  return {
  //  showNewButton: false,
  //  showCloseButton: true,
  //  container: this.container,
  //  image: img,
  //  assets: { baseUrl: "/content/smilestream/pesdk2/assets" },
  //  title: "Import image",
  //  tools: ["crop", "rotation", "flip", "brightness", "saturation", "contrast", "tilt-shift"],
  //  export: {
  //    showButton: true,
  //    format: "image/jpeg",
  //    type: PhotoEditorSDK.RenderType.DATAURL,
  //    quality: 1.0,
  //    download: false
  //  }
  //};
  return {
      container: this.container,
      //license: '{"owner":"Praxus","version":"2.1","enterprise_license":false,"available_actions":["magic","filter","transform","sticker","text","adjustments","brush","focus","frames","camera"],"features":["adjustment","filter","focus","overlay","transform","text","sticker","frame","brush","camera","textdesign","library","export"],"platform":"HTML5","app_identifiers":["www.dev.smilestream.com","*.smilestream.com","192.168.0.5"],"api_token":"kQqZTPDUoeCc-ShzuRny_Q","domains":["https://api.photoeditorsdk.com"],"issued_at":1525668382,"expires_at":1527897600,"signature":"BSA9VqTNvyknY/mfF5Mm+YR2DIW1hdMT0NZLxtVMNqIYGtxi+T0trxmuA2DE5NxfmgTbd/+z4L2sdxe35greHhiXl5ZnnFw+2Q3tZzSdAjr0EgsXrU1rXKvX0Jo+77+Ie/JzUkkqwbRjAHjzSD/dRlLLypyFsguii9gUtjwKB+HwaQn9iiq2bWQFMjhUY8CDRxjrHvOcQuRmgTRTiygX6MhlB2I0pu3lWFjTiWGeuACdeGnVaui2xvRt2MpaJUzksBVGMhimz3Ko3BPoReRoEn8vsklTh13uRkkQJTywmG2hbPpjfJtqM7+mJSe3MEQ79jvsgnfZIEFhnK1LDJGh5Wk7doocgwCoh5HR4cTE0IUMRMDzWpSugWwflXWSqni3NsSql5rBeiBtNYQxleSkJIwq+nJrVmtO4h4v1+lHg+e7qiLthqZ2UChBTBdGE1H5CZ91SbR1DedI2vnxPet5cONLoWoVeXfQYcYONu6RPqTUBFrw7g1+j+NHtkQVsrmgczPFpzS9q+6ibn5BUSFJoTbEuQ5oyx6dHnVgmGfvLcVhEBgWHLoEBHj0APF2PQR/9XwdpGevrK2dkV5IgY5xt3MkiHli2o2LjwK0TzPu76cfmFjuiFahFJj3IEtPbF3f9fUdDlZZ3yh2MMnCymIJrRhiK5ODRmLIYnpFCNep7rg="}',
      //license: '{"owner":"Praxus","version":"2.1","enterprise_license":false,"available_actions":["magic","filter","transform","sticker","text","adjustments","brush","focus","frames","camera"],"features":["magic","filter","transform","sticker","text","adjustments","brush","focus","frames","export"],"platform":"HTML5","app_identifiers":["www.smilestream.com","*.smilestream.com","www.dev.smilestream.com","*.dev.smilestream.com","192.168.0.5"],"api_token":"GRR9oM3y5TdLceuh5JGsJQ","domains":["https://api.photoeditorsdk.com"],"issued_at":1526015031,"expires_at":null,"signature":"pioBVxd2r6GvSZzPCKylHUzzz7DpAXpJeQykMV2OftMV6XRtbM54q+8f/esT5VTiE92p1xuL34XZ1L5Lu20Gof4Onenlf8oPOa1NZmZyJixSwaqbv4o22EL7mFzehIomfimNY9GahT0jfmMO2w5sLrfIAWqnVrc8XQ2TWWLO4S6Xh9mfqcnO5KwKwU1f1hotHyy7ssZ7KvtdRSxG1WpFgDyLdJok4R5+CZ6Ms85Y6GX3gViytirD9yrzbZ+66a7NZtP9+7gpDaMkLsRTll5LGNNs6DiV+O/if+8LBlRmCl6iosEiOLR+gK7dUxIzzuYnQa+xgkiRHooDSo9L0czY2xrtls7ls/A1hlv8YmYR57tLIhFgKfVPiueDu/JjrzPzE6Oig3AihkCTsG9gZgG2Xk2+WLuS4t6o70Z8ZIKQc12Jh92vf6eVjkrxqTNFtNx1PeQBs18C27/DCZi3ltWNJ4eoldOyxscYpXhFSNpD5qXG1jFQyoxKcBKTF/NgZI+6umLy4h/aC3qzz+1EgzLL+5vYy9m5RQpB+lO81MQ0vx1Hg6tHWEBfbpdMqIXQhED6ezmwKWSQjQ9MHesRZv722DCtmqN13/dnAKG1Ke+HVcYIdZ0dFQqn4SbEHGpi7osgHg4eMvFvQOSEqslvP+Y5cTv6Lat1s/p2J1P2mUtwsAU="}',
      //license: '{"owner":"Praxus","version":"2.1","enterprise_license":false,"available_actions":["magic","filter","transform","sticker","text","adjustments","brush","focus","frames","camera"],"features":["transform","adjustments","camera","library","export"],"platform":"HTML5","app_identifiers":["www.dev.smilestream.com","*.dev.smilestream.com"],"api_token":"GRR9oM3y5TdLceuh5JGsJQ","domains":["https://api.photoeditorsdk.com"],"issued_at":1526025135,"expires_at":null,"signature":"ZK7sUDIhINWEvBZmT8v252cfCYX6KxLF7M/0+dJHpNFzdZeA+Rl/DqbX0PWwOlmFodZUSKS+kaSGWLuXoEWN4t8erKOrmBzxFfWJy4d+zo/dPUlYPXcrJZNI/ryjW04iq4B0zp/ZY1HFHfUt5lzlrRD+aUSV+Ke6dzbEzuz1aPaCdUoBFnTISKeGfZzpFIzIBcBc+z1HCFISJupugkK8qJfK3W9LOA/sOHCO3aP3XfafqFKgxE5ew4d3x2jM/Lbq4d6IfUtOPKS29u7d27/EqoW3+p3QqH4yCTqTQ2ol1kPFeZqwuXvf3VbxDyFVhIb5V4Eu9faQMCvbWzc/nVCUFcmC+Vc+JaviI8H+ph9ROsP7vsCzYQSJLDGf4lMW85ZU5m0pn/smhI/kDspfdOC7CifEx4A61Kjm5Fpm6USIO2IdMblE899E57p4/ivdtPmcJNygAQV351kSm2leppD8hBt5KrB/V+6TmUj+iQooqlOHJ1V6ZHdIFE82cMYCryVvLKbst/NSPQOqGfCcW0n8NXETBLKZXPLVDFh+t97/fQfpE9FUXdCs3igkLIQ7HmzbEgGwWQCLDys7PhZdDAEx1pcUPHVRE+3WPYwW1hc2Fhl/J7u/mb8XIKnBks4ib7c5U8Xul73SSQTuqm1jzKSntV6dIC0bl2JO6rr4D3YSWFY="}',
      license: '{"owner":"Praxus","version":"2.1","enterprise_license":false,"available_actions":["magic","filter","transform","sticker","text","adjustments","brush","focus","frames","camera"],"features":["transform","camera","library","export"],"platform":"HTML5","app_identifiers":["www.smilestream.com","*.smilestream.com","localsmilestream.com","192.168.0.5"],"api_token":"GRR9oM3y5TdLceuh5JGsJQ","domains":["https://api.photoeditorsdk.com"],"issued_at":1526362034,"expires_at":null,"signature":"PM1tbUqlYy13esMbeMbdudUh0A9u7tRQTrbUZZtB71tyAaubxfdWVeYQgrn6mRP3m1HfGjevQo952dOd/ZE8YLq0A/JkHa3CuIFEyT/y+/KHER0fJc0t7TaMrEkQ88kKnLgXiWAc4FkNusUwUdrxgQw8qisixRHVvqPf0OMdtrO32wnq1jP0E1ueSucrRKF5BTCkOMMFKKkVOZaNG+/aJ6xL/FLtYpXoX/V+h71e/YHkZs/iET+d5dd4uJPA3VKnUrBecZGEneSffdV24ZJfAVflWzxTkZJCn+gvLU1l298OQ4BszM+4/GXrr8Bw17dEjb8XusmYta1q2WhF0yxesLoSSzZiYMUXFNTBNO+LMVw3K5uQCttNwyrwpW+c3kyR6PBKeAI6rLc3dnnFlrouG/lLw5KR34PEqdlodoAyxohuiAl6KGV31r6dLUYrBnxrs+f29VGtUbICA4VL5S3SvmxzzXxDBD7cHogRYiHMyScd07PaOi4Di2SBPSrNmtz63BJR2MAHaenNnzczf3Iy6wrh6tHIO3lvGwf+xx7IOUg1wTGT/qUiuPBJ4Q8ulDQpOLMNlWoeAXAdtyHYARH7P1jbAp9+sxaiTaFFijlEJwnBNf+adK8si6w0jnmX5I704gBcF9yk5FcudvO6K6KPGcop6z3Mc2URE16t6pBWSWc="}',
      title: "Edit Picture",
      showNewButton: false,
      enableUpload :false,
      showCloseButton: true,
      displayResizeMessage: false,
      assets: { baseUrl: "pesdk/assets" },
      transparent: true,
      editor: {
          image: img,
          tools: ['transform', 'adjustments'],
          controlsOptions: {
              adjustments: {
                  availableAdjustments: ['brightness', 'saturation', 'contrast']
              },
              transform: {
                  availableRatios: ['imgly_transform_common_custom', 'imgly_transform_common_square', 'imgly_transform_common_4-3','imgly_transform_common_16-9']
              }
          },
          export: {
              showButton: true,
              format: "image/jpeg",
              type: PhotoEditorSDK.RenderType.DATAURL,
              quality: 1.0,
              download: false
          }
      }
  };
}

ImageEditor.OnImageEdited = function (imageAsBase64) {

  var i = new Image();
  i.onload = function () {
    console.log("End editing picture (2). Size of picture: " + this.width + "x" + this.height);
  };
  i.src = imageAsBase64;

  if (typeof (IsSaveProcess) != "undefined") {
    IsSaveProcess = isDataURL(imageAsBase64)
  }

  if (typeof (this.OnEdited) == "function") {
    this.OnEdited(imageAsBase64);
  }
  else if (typeof (document.onImageEdited) == "function") {
    document.onImageEdited(imageAsBase64);
  }

  this.editor = null;
  this.ClearEditorContainer();
}

ImageEditor.Launch = function (img, url, mustPortraitOrientationBeUsed) {
  if (img == null) {
    img = new Image();
    img.src = url;
    var editor = this;
    img.onload = function () {
      console.log("Start editing picture. Size of picture: " + img.width + "x" + img.height);
      editor.LaunchImpl(img, mustPortraitOrientationBeUsed);
    }
  }
  else {
    this.LaunchImpl(img, mustPortraitOrientationBeUsed);
  }
}

ImageEditor.LaunchImpl = function (img, mustPortraitOrientationBeUsed) {
  var self = this;

  this.editor = new PhotoEditorSDK.UI.ReactUI(this.GetEditorParams(img, mustPortraitOrientationBeUsed));
  this.editor.on('export', this.OnImageEdited.bind(this));
  this.editor.on('close', function () {
    console.log("End editing picture. Size of picture: " + img.width + "x" + img.height);
    self.OnImageEdited(img.src);
  });
}


function isDataURL(s) {
  return !!s.match(isDataURL.regex);
}
isDataURL.regex = /^\s*data:([a-z]+\/[a-z]+(;[a-z\-]+\=[a-z\-]+)?)?(;base64)?,[a-z0-9\!\$\&\'\,\(\)\*\+\,\;\=\-\.\_\~\:\@\/\?\%\s]*\s*$/i;